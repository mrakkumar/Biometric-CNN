Tutorials
=========

- craffel's [Theano tutorial](https://github.com/craffel/theano-tutorial)
- craffel's [Lasagne tutorial](https://github.com/craffel/Lasagne-tutorial/blob/master/examples/tutorial.ipynb)
- ebenolson's [Theano and Lasagne tutorial](https://github.com/ebenolson/pydata2015)